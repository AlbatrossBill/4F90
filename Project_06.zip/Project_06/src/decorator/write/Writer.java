package decorator.write;

public abstract class Writer {
    public abstract void writeXMLObject(Object obj);
}
