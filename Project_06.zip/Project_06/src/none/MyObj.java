package none;

public class MyObj{
    public int anInt;
    public double aDouble;
    protected String aString;

//    @Override
//    public String toString() {
//        return "MyObj{" +
//                "anInt=" + anInt +
//                ", aDouble=" + aDouble +
//                ", aString='" + aString + '\'' +
//                '}';
//    }


    @Override
    public String toString() {
        return "MyObj{" +
                "anInt=" + anInt +
                ", aDouble=" + aDouble +
                ", aString='" + aString + '\'' +
                '}';
    }
}
