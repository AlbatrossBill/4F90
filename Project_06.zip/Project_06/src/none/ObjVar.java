package none;

public class ObjVar {
    public int height;
//    public String gender = "Male";
//    protected double shoe = 10.5;
    public MyVar myVar;


    @Override
    public String toString() {
        return "ObjVar{" +
                "height=" + height +
                ", myVar=" + myVar +
                '}';
    }
}
